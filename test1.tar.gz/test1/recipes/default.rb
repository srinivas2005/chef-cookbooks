#
# Cookbook Name:: test1
# Recipe:: default
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

package 'httpd'
service 'httpd' do
  action [:enable, :start]
end

template 'httpd.conf' do
          path '/etc/httpd/conf/httpd.conf'
          source 'httpd.conf.erb'
end
service 'httpd' do
         action [ :enable, :restart ]
end




































