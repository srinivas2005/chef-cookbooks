#
# Cookbook Name:: user_create
# Recipe:: default
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

user 'srini' do
  comment 'A random user'
  uid '1234'
  gid '1234'
  home '/home/srini'
  shell '/bin/bash'
  password 'srini123'
end
